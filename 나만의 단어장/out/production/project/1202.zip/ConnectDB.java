

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static java.lang.String.join;

// DB 연결 클래스
public class ConnectDB {
    // 클래스 객체 변수 선언
    Connection conn;	// DB 연결에 사용되는 객체 변수
    Statement stmt;		// sql 명령어 실행에 사용되는 객체 변수
    ResultSet result;	// sql 명령의 실행결과를 받는 객체 변수

    // 접속할 데이터베이스의 URL, 아이디, 패스워드 설정
    String url;					// "jdbc:mysql://localhost:3306/[데이터베이스 이름]?serverTimezone=UTC"
    String mysql_id = "root";	// DB root 아이디
    String mysql_pw = "495108";	// MYSQL 설정 시 입력한 패스워드

    // 입력한 아이디가 서버에 등록되어 있는지 검사하는 메소드 (id를 매개변수로 받음)
    public boolean checkId(String id) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료 : checkId");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String id_check_sql = "select exists(select * from user_list where id = '" + id + "')";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 입력된 id가 'user_list' 테이블에 있는지 검사
            result = stmt.executeQuery(id_check_sql);
            result.next();
            int id_check_result = result.getInt(1);		// 있다면 1, 없다면 0

            // 연결 해제(사용된 자원을 반환)
            result.close();
            stmt.close();
            conn.close();

            // 결과값 리턴
            if (id_check_result == 1) {
                return true;	// 입력된 id가 DB에 있으면 true
            }
            else {
                return false;	// 없으면 false
            }
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return false;
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: checkId");
            return false;
        }
    }

    // 입력한 패스워드가 해당 id의 패스워드와 일치하는지 검사하는 메소드 (id와 pw를 매개변수로 받음)
    public boolean checkPw(String id, String pw) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료: checkPw");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String pw_get_sql = "select password from user_list where id = '" + id + "'";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 입력된 id에 해당하는 password를 조회
            result = stmt.executeQuery(pw_get_sql);
            result.next();
            String password = result.getString(1);
            // 연결 해제(사용된 자원을 반환)
            result.close();
            stmt.close();
            conn.close();

            // 결과값 리턴
            if (pw.equals(password)) {
                return true;	// 입력된 패스워드가 해당 id의 패스워드와 일치하면 true
            }
            else {
                return false;	// 일치하지 않으면 false
            }
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return false;
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: checkPw");
            return false;
        }
    }

    // 입력한 아이디, 패스워드, 이름, 성별, 생년월일, 이메일을 DB에 추가하는 메소드
    public void addMember(String id, String pw, String name, String gender, String email) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료:addMember");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql1 = "insert into user_list values('" + id + "', '" + pw + "', '" + name + "', '"
                    + gender + "', '" + email + "')";
            String sql2 = "create database " + id + "_db";
            String sql3 = "use " + id + "_db";
            String sql4 = "create table note_list ("
                    + "id int NOT NULL AUTO_INCREMENT PRIMARY KEY,"
                    + "name varchar(30) NOT NULL)";


            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // sql 명령어 실행
            stmt.executeUpdate(sql1);	// 'user_list' 테이블에 새로운 회원정보 삽입
            stmt.executeUpdate(sql2);	// 회원가입 시에 입력한 아이디로 회원 개인 DB 생성
            stmt.executeUpdate(sql3);	// 회원 개인 DB로 이동
            stmt.executeUpdate(sql4);	// 회원 개인 DB에 'note_list' 테이블 생성

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: addMember");
        }
    }
    // 회원정보를 조회하는 메소드
    public String lookProfile(String id) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료: lookProfile");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String look_sql = "select * from user_list where id = '" + id + "'";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 로그인한 id에 해당하는 회원정보를 조회
            result = stmt.executeQuery(look_sql);
            result.next();
            String profile = result.getString("id");
            profile = profile + "/" + result.getString("name");
            profile = profile + "/" + result.getString("gender");
            profile = profile + "/" + result.getString("email");

            // 연결 해제(사용된 자원을 반환)
            result.close();
            stmt.close();
            conn.close();

            return profile;
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return null;
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: lookProfile");
            return null;
        }
    }

    // 회원정보를 수정하는 메소드
    public void editProfile(String id, String name, String gender, String email) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료: editProfile");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql = "update user_list set name = '" + name + "', gender = '" + gender + "', email = '"
                    + email + "' where id = '" + id + "'";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 로그인한 id에 해당하는 회원정보를 수정
            stmt.executeUpdate(sql);

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: editProfile");
        }
    }
    // 비밀번호를 변경하는 메소드
    public void editPassword(String id, String pw) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료: editPassword");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql = "update user_list set password = '" + pw + "' where id = '" + id + "'";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 로그인한 id에 해당하는 비밀번호를 변경
            stmt.executeUpdate(sql);

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: editPassword");
        }
    }

    // 회원을 삭제하는 메소드
    public void deleteMember(String id) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";	// 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료:deleteMember");								// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql = "delete from user_list where id = '" + id + "'";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 로그인한 id에 해당하는 회원을 DB에서 삭제
            stmt.executeUpdate(sql);

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
            System.out.println("유저"+id+": 회원 탈퇴 완료");
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: deleteMember");
        }
    }


    // 회원을 삭제하는 메소드
    public void delete_UserDB(String id) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/?serverTimezone=UTC";	// 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료:delete_UserDB");					// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql = "drop database " + id + "_db";
            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            //로그인한 id에 해당하는 회원의 단어db를 삭제
            stmt.executeUpdate(sql);

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: delete_UserDB");
        }
    }

    // 사용자의 이름을 조회하는 메소드
    public String select_name(String id) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/member?serverTimezone=UTC";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);
            System.out.println("DB 연결 완료: select_name");
            // SQL 쿼리
            String query = "SELECT name FROM user_list WHERE id = '" + id + "'";

            // Statement 객체 생성
            stmt = conn.createStatement();

            // 쿼리 실행
            ResultSet result = stmt.executeQuery(query);

            // 결과 처리
            String name = null;
            while (result.next()) {
                // 'name' 열의 값을 얻음
                name = result.getString("name");
            }

            // 연결 해제
            result.close();
            stmt.close();
            conn.close();
            // 최종 결과값 리턴
            return name;

        } catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return null;
        } catch (SQLException e) {
            System.out.println("DB 연결 오류: select_name");
            e.printStackTrace(); // 예외 출력
            return null;
        }

    }

    //새로운 노트를 추가하는 메소드
    public void add_NoteTable(String id,String note_Name) { //노트 이름을 전달받음
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/"+id+"_db?serverTimezone=UTC";    // 'member' 데이터베이스로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");                        // JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);    // 데이터베이스와 연결
            System.out.println("DB 연결 완료:add_NoteTable");                                // DB 연결 성공 여부를 콘솔 창에 출력
            //sql명령문
            String createTableQuery = "CREATE TABLE `" + note_Name + "` (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +  //연번
                    "word VARCHAR(255)," +  //단어
                    "mean VARCHAR(255)," +  //뜻
                    "pos VARCHAR(50)" +   //품사
                    ")";

            String insertNoteNameQuery = "insert into note_list (name) values ('" + note_Name + "')";
            // stmt 객체 변수 활성화
            stmt = conn.createStatement();
            //노트n 테이블 생성
            stmt.executeUpdate(createTableQuery);					// 노트n 테이블 생성
            System.out.println(note_Name + "테이블 생성 완료.");
            stmt.executeUpdate(insertNoteNameQuery);				// 새 노트 이름을 'note_list' 테이블에 삽입
            System.out.println("note_list: 노트 이름 삽입 완료");

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        } catch (SQLException e) {
            System.out.println("DB 연결 오류:add_NoteTable");

        }
    }
    //해당 사용자의 단어db에 해당하는 노트table에 단어 추가하는 메소드
    public void insert_word(String id, String noteName , String word, String mean, List<String> pos) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");								// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);			// 데이터베이스와 연결
            System.out.println("DB 연결 완료:insert_word");										// DB 연결 성공 여부를 콘솔 창에 출력

            String sql = "INSERT INTO `" + noteName + "` (word, mean, pos) VALUES ('"+word+"', '"+mean+"','"+pos+"')";
            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            stmt.execute(sql);
            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
            System.out.println("인서트 완료");
            }

        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: insert_word");
            e.printStackTrace();
        }
    }
    //해당 사용자의 단어db에 해당하는 노트table에 단어 삭제하는 메소드
    public void delete_word(String id, String noteName , String word[]) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");								// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);			// 데이터베이스와 연결
            System.out.println("DB 연결 완료:delete_word");										// DB 연결 성공 여부를 콘솔 창에 출력

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();


            for (int i = 0; i < word.length; i++) {
                String sql = "DELETE FROM `" + noteName + "` WHERE word = '" + word[i] + "'";
                stmt.execute(sql);
            }

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
            System.out.println("단어 삭제 완료");
        }

        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: delete_word");
            e.printStackTrace();
        }
    }



    // 해당 노트에 추가된 모든 단어를 조회하는 메소드
    public String[][] lookEnglish(String id, String note_name) {	// 2차원 배열을 리턴
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");								// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);			// 데이터베이스와 연결
            System.out.println("DB 연결 완료");										// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql1 = "select count(*) from `" + note_name +"`";
            String sql2 = "select * from `" + note_name + "`";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // sql 명령어 실행
            result = stmt.executeQuery(sql1);	// 노트에 있는 영단어의 개수를 조회
            result.next();						// 커서를 다음 행으로 이동
            int count = result.getInt(1);		// 영단어의 개수를 count에 저장
            String[][] english;					// 모든 단어, 뜻, 품사를 저장할 2차원 배열 선언
            if (count > 0) {					// 노트에 영단어가 있다면..
                english = new String[count][3];		// count*3만큼의 크기를 가지는 2차원 배열 생성
                result = stmt.executeQuery(sql2);	// 노트에 있는 모든 단어, 뜻, 품사를 조회
                for (int i=0; i<count; i++) {
                    result.next();						// 커서를 다음 행으로 이동
                    for (int j=0; j<3; j++) {
                        english[i][j] = result.getString(j+2);	// 결과의 인덱스 번호를 이용하여 컬럼 값을 저장
                    }
                }
            }
            else {								// 노트에 단어가 없다면..
                english = null;						// 2차원 배열 english를 생성하지 않음
            }

            // 연결 해제(사용된 자원을 반환)
            result.close();
            stmt.close();
            conn.close();

            // 모든 단어, 뜻, 품사를 가지는 english를 반환
            return english;
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return null;
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류");
            return null;
        }
    }

    //word 컬럼, mean컬럼을 조회하는 메소드
    public String[][] select_word(String id, String noteName) {
        //조회한 단어를 받기 위한 배열 선언
        String word_list[][];
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");								// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);			// 데이터베이스와 연결
            System.out.println("DB 연결 완료:select_word");										// DB 연결 성공 여부를 콘솔 창에 출력
            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // sql 명령어를 가지는 문자열 변수 생성
            String sql1 = "select count(*) from `" + noteName +"`";
            String sql2 ="select word,mean from "+noteName;


            result = stmt.executeQuery(sql1);	// 노트에 있는 영단어의 개수를 조회
            result.next();						// 커서를 다음 행으로 이동
            int count = result.getInt(1);		// 영단어의 개수를 count에 저장

            if(count>0) { //단어가 있으면...
                word_list = new String[count][2];  //영단어 개수만큼 배열 생성

                // 실행결과를 ResultSet으로 반환 받음
                ResultSet resultSet = stmt.executeQuery(sql2);

                // 단어, 뜻 추가
                for (int i=0; i<count; i++) {
                    resultSet.next();						// 커서를 다음 행으로 이동
                    for (int j=0; j<2; j++) {
                        word_list[i][j] = resultSet.getString(j+1);	// 결과의 인덱스 번호를 이용하여 컬럼 값을 저장
//                        System.out.println("영단어/뜻:"+word_list[i][j]);
                    }
                }
            }

            else{ //단어가 없다면...
                word_list=null;
            }
            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
            return  word_list;
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return null;
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: select_word");
            e.printStackTrace();
            return null;
        }

    }


    // 모든 노트를 조회하는 메소드
    public String select_NoteList(String id) {
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");								// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);			// 데이터베이스와 연결
            System.out.println("DB 연결 완료:select_NoteList");										// DB 연결 성공 여부를 콘솔 창에 출력

            // sql 명령어를 가지는 문자열 변수 생성
            String sql = "select name from note_list";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 로그인한 회원이 추가한 모든 노트의 이름을 조회
            result = stmt.executeQuery(sql);
            String note = null;		// 모든 노트의 이름을 저장할 변수 생성
            if (result.next()) {								// DB에 노트가 있다면..
                note = result.getString("name");					// note에 노트 이름을 추가
                while (result.next()) {								// 결과의 두 번째 행부터 마지막 행까지..
                    note = note + "|" + result.getString("name");		// 각 노트의 이름을 '|'로 구분하여 note에 추가
                }
            }

            // 연결 해제(사용된 자원을 반환)
            result.close();
            stmt.close();
            conn.close();
            // 모든 노트의 이름을 가지는 문자열 변수 note를 반환
            return note;  //t|tt
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            return null;
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: select_NoteList");
            return null;
        }
    }
        //노트를 삭제하는 메소드
        public void del_NoteTable(String id, String note_Name){ //노트 이름을 전달받음
            try {
                // DB 연결
                url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
                Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
                conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
                System.out.println("DB 연결 완료: del_NoteTable");								// DB 연결 성공 여부를 콘솔 창에 출력
                //sql명령문
                String deleteTableQuery="DROP TABLE " + note_Name;
                String deleteNoteNameQuery = "delete from note_list where name = '" + note_Name + "';";
                // stmt 객체 변수 활성화
                stmt = conn.createStatement();
                //노트n 테이블 생성
                stmt.executeUpdate(deleteTableQuery);
                System.out.println("Delete Table: "+note_Name);
                stmt.executeUpdate(deleteNoteNameQuery);			// 'note_list' 테이블에서 해당 노트 이름을 삭제

                // 연결 해제(사용된 자원을 반환)
                stmt.close();
                conn.close();
            }
            catch (ClassNotFoundException e) {
                System.out.println("JDBC 드라이버 로드 에러");
            }
            catch (SQLException e) {
                System.out.println("DB 연결 오류: del_NoteTable");
            }
    }
    //모든 노트의 단어를 조회하는 메소드 
    public String[] select_words(String id, String searchWord) {  //찾을 단어를 hand라고 가정
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";	// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");								// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);			// 데이터베이스와 연결
            System.out.println("DB 연결 완료:select_words");										// DB 연결 성공 여부를 콘솔 창에 출력
            String[] word = new String[3];    //[단어,뜻,찾은 노트 이름]를 반환받을 배열

            // sql 명령어를 가지는 문자열 변수 생성
            String sql = "select name from note_list";

            // stmt 객체 변수 활성화
            stmt = conn.createStatement();

            // 로그인한 회원이 추가한 모든 노트의 이름을 조회
            result = stmt.executeQuery(sql);

            // 모든 노트의 이름을 배열에 저장
            ArrayList<String> noteNameList=new ArrayList<String>();
            // DB에 노트가 있다면..
            while (result.next()) {	//다음 행이 있을떄까지 반복
                noteNameList.add(result.getString("name"));  // 모든 노트를 탐색하기 위해 note이름을 리스트에 저장함
//                    System.out.println("리스트:"+noteNameList);  //[test1, test2, test3]
            }
//            System.out.println(searchWord);  //hand 출력됨 - 성공

            //단어,뜻 조회 시작
            for (int i = 0; i < noteNameList.size(); i++) {
                //sql명령어
                String sql2 = "SELECT word,mean FROM " + noteNameList.get(i) + " where word = '" + searchWord+"'";
                result = stmt.executeQuery(sql2); //각 노트별로 모든 단어 조회
                while (result.next()) {
                    // 현재 행의 word와 mean 값을 읽어오기
                    word[0] = result.getString("word");
                    word[1] = result.getString("mean");
                    if(word[0].equals(searchWord)) {
                        word[2]=noteNameList.get(i); //찾은 단어의 노트를 저장
                        System.out.println(noteNameList.get(i) + "에서찾은 단어:" + word[0]); //있는 단어 검색시 :  찾은 단어:hand
                        break;
                    }
                    else {            // 못찾으면 null을 가진 배열을 word[null,null]반환함
                        System.out.println(noteNameList.get(i) +"못찾은 단어:"+word[0]);  //못찾으면 null반환됨
                    }
                }
            }
            // 연결 해제(사용된 자원을 반환)
            result.close();
            stmt.close();
            conn.close();
            // word배열 반환
            return word;

        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
            e.printStackTrace();
            return null;

        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: select_words");
            e.printStackTrace();
            return null;
        }
    }



    //노트 테이블의 행의 개수를 반환하는 메소드
    public int get_NoteTableSIZE(String id,String noteName){ //노트 이름을 전달받음
        int rowCount = 0;
        try {
            // DB 연결
            url = "jdbc:mysql://localhost:3306/" + id + "_db?serverTimezone=UTC";// 회원 개인 DB로 접속하는 URL
            Class.forName("com.mysql.cj.jdbc.Driver");						// JDBC드라이버 로드
            conn = DriverManager.getConnection(url, mysql_id, mysql_pw);	// 데이터베이스와 연결
            System.out.println("DB 연결 완료: get_NoteTableSIZE");								// DB 연결 성공 여부를 콘솔 창에 출력
            //sql명령문
            String Query="select count(*) from `" + noteName+"`";
            // stmt 객체 변수 활성화
            stmt = conn.createStatement();
            //테이블 행의 갯수 반환
            ResultSet rs=stmt.executeQuery(Query);
            if (rs.next()) {
                rowCount = rs.getInt(1);
                System.out.println(noteName + "의 행의 갯수: " + rowCount);
            }

            // 연결 해제(사용된 자원을 반환)
            stmt.close();
            conn.close();
        }
        catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 에러");
        }
        catch (SQLException e) {
            System.out.println("DB 연결 오류: get_NoteTableSIZE");
        }
        return rowCount;
    }

}